import random
from collections import deque, namedtuple
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.distributions.normal import Normal
from torch.nn.functional import mse_loss
from RL_Algorithm.RL_base_function import BaseAlgorithm
import os

class Actor(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, learning_rate=1e-4):
        """
        Actor network for policy approximation.

        Args:
            input_dim (int): Dimension of the state space.
            hidden_dim (int): Number of hidden units.
            output_dim (int): Dimension of the action space.
            learning_rate (float, optional): Learning rate for optimization. Defaults to 1e-4.
        """
        super(Actor, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, output_dim)
        
        self.init_weights()
        
    def init_weights(self):
        """
        Initialize network weights using Xavier initialization for better convergence.
        """
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)  # Xavier initialization for weights
                nn.init.zeros_(m.bias)  # Bias set to zero

    def forward(self, state):
        """
        Forward pass for action selection.

        Args:
            state (Tensor): Current state of the environment.

        Returns:
            Tensor: Selected action values (in range -1 to 1) from tanh.
        """
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        # produce output in (-1,1); scaling can be applied later if needed
        action = torch.tanh(self.fc3(x))
        return action

    
        # x = torch.relu(self.fc1(state))
        # x = torch.relu(self.fc2(x))
        # action = torch.tanh(self.fc3(x))
        # return action
    

class Critic(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim, learning_rate=1e-4):
        """
        Critic network for Q-value approximation.

        Args:
            state_dim (int): Dimension of the state space.
            action_dim (int): Dimension of the action space.
            hidden_dim (int): Number of hidden units.
            learning_rate (float, optional): Learning rate for optimization. Defaults to 1e-4.
        """
        super(Critic, self).__init__()
        # Input คือ concatenation ของ state และ action
        self.fc1 = nn.Linear(state_dim + action_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, 1)
        
        self.init_weights()
        
    def init_weights(self):
        """
        Initialize network weights using Kaiming initialization.
        """
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight, nonlinearity='relu')
                nn.init.zeros_(m.bias)

    def forward(self, state, action):
        """
        Forward pass for Q-value estimation.

        Args:
            state (Tensor): Current state of the environment.
            action (Tensor): Action taken by the agent.

        Returns:
            Tensor: Estimated Q-value.
        """
        # Concatenate state and action along the feature dimension (assume batch dim=0)
        x = torch.cat([state, action], dim=1)
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        q_value = self.fc3(x)
        return q_value
    
    
        # state = state.contiguous()  # ไม่จำเป็นต้อง clone
        # action = action.contiguous()
        # x = torch.cat([state, action], dim=1)
        # x = torch.relu(self.fc1(x))
        # x = torch.relu(self.fc2(x))
        # q_value = self.fc3(x)
        # return q_value

class Actor_Critic(BaseAlgorithm):
    def __init__(self, 
                device = None, 
                num_of_action: int = 2,
                action_range: list = [-2.5, 2.5],
                n_observations: int = 4,
                hidden_dim = 256,
                dropout = 0.05, 
                learning_rate: float = 0.01,
                tau: float = 0.005,
                discount_factor: float = 0.95,
                buffer_size: int = 256,
                batch_size: int = 1,
                ):
        """
        Actor-Critic algorithm implementation.

        Args:
            device (str): Device to run the model on ('cpu' or 'cuda').
            num_of_action (int, optional): Number of possible actions. Defaults to 2.
            action_range (list, optional): Range of action values. Defaults to [-2.5, 2.5].
            n_observations (int, optional): Number of observations in state. Defaults to 4.
            hidden_dim (int, optional): Hidden layer dimension. Defaults to 256.
            learning_rate (float, optional): Learning rate. Defaults to 0.01.
            tau (float, optional): Soft update parameter. Defaults to 0.005.
            discount_factor (float, optional): Discount factor for Q-learning. Defaults to 0.95.
            batch_size (int, optional): Size of training batches. Defaults to 1.
            buffer_size (int, optional): Replay buffer size. Defaults to 256.
        """
        # Feel free to add or modify any of the initialized variables above.
        # ========= put your code here ========= #
        self.device = device
        self.lr = learning_rate

        self.actor = Actor(n_observations, hidden_dim, num_of_action, learning_rate).to(device)
        self.actor_target = Actor(n_observations, hidden_dim, num_of_action, learning_rate).to(device)
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=self.lr)
        
        self.critic = Critic(n_observations, num_of_action, hidden_dim, learning_rate).to(device)
        self.critic_target = Critic(n_observations, num_of_action, hidden_dim, learning_rate).to(device)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=self.lr)

        self.batch_size = batch_size
        self.tau = tau
        self.discount_factor = discount_factor

        self.update_target_networks(tau=1)  # initialize target networks

        # Experiment with different values and configurations to see how they affect the training process.
        # Remember to document any changes you make and analyze their impact on the agent's performance.

        pass
        # ====================================== #

        super(Actor_Critic, self).__init__(
            num_of_action=num_of_action,
            action_range=action_range,
            learning_rate=learning_rate,
            discount_factor=discount_factor,
            buffer_size=buffer_size,
            batch_size=batch_size,
        )


    def select_action(self, state, noise=0.1):
        """
        Selects an action based on the current policy with optional exploration noise.
        
        Args:
        state (Tensor): The current state of the environment.
        noise (float, optional): The standard deviation of noise for exploration. Defaults to 0.1.

        Returns:
            Tuple[Tensor, Tensor]: 
                - scaled_action: The final action after scaling.
                - clipped_action: The action before scaling but after noise adjustment.
        """
        
        # Process the state input (if it is a dict, take key 'policy')
        if isinstance(state, dict) and 'policy' in state:
            state_tensor = state['policy']
        else:
            if not torch.is_tensor(state):
                state_tensor = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
            else:
                state_tensor = state.unsqueeze(0) if state.dim() == 1 else state

        self.actor.eval()
        with torch.no_grad():
            raw_action = self.actor(state_tensor)
        self.actor.train()

        # Add Gaussian noise for exploration
        if noise > 0:
            noise_tensor = torch.randn_like(raw_action) * noise
            raw_action = raw_action + noise_tensor

        # Scale raw_action from [-1, 1] to the environment's action range, using function scale_action from BaseAlgorithm
        # (Assume scale_action accepts a tensor or its item; here we do it elementwise for each action value)
        # For simplicity, apply scaling elementwise:

        scaled_action = []
        for a in raw_action.squeeze(0):
            a_val = a.item()
            action_min, action_max = self.action_range
            scaled = action_min + (a_val + 1) * (action_max - action_min) / 2.0
            scaled_action.append(scaled)
        # ใช้ตัวแปร scaled_action ที่ได้จากวนลูปในการแปลงเป็น tensor
        scaled_action = torch.tensor(scaled_action, dtype=torch.float32, device=self.device).view(-1, 1)


        return scaled_action, raw_action

        # # Process state input (if it's a dict, take the value at 'policy')
        # if isinstance(state, dict) and 'policy' in state:
        #     state_tensor = state['policy']
        # else:
        #     if not torch.is_tensor(state):
        #         state_tensor = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        #     else:
        #         state_tensor = state.unsqueeze(0) if state.dim() == 1 else state

        # self.actor.eval()
        # with torch.no_grad():
        #     raw_action = self.actor(state_tensor)  # Expected shape: [batch_size, num_of_action]
        # self.actor.train()

        # # Add Gaussian noise for exploration
        # if noise > 0:
        #     noise_tensor = torch.randn_like(raw_action) * noise
        #     raw_action = raw_action + noise_tensor

        # # Scale raw_action from [-1,1] to the environment's action range
        # # ทำ scaling แบบ elementwise สำหรับแต่ละ action (เนื่องจาก output คาดว่าจะเป็น continuous)
        # scaled_action_list = []
        # for a in raw_action.squeeze(0):  # ลด batch dim หาก batch_size==1
        #     a_val = a.item()
        #     action_min, action_max = self.action_range
        #     scaled = action_min + (a_val + 1) * (action_max - action_min) / 2.0
        #     scaled_action_list.append(scaled)
        # # สร้าง tensor จาก list และจัดรูปแบบให้มี shape [batch_size, 1]
        # # scaled_actions = torch.tensor(scaled_action_list, dtype=torch.float32, device=self.device).view(-1, 1)
        # scaled_actions = torch.tensor(scaled_action_list, dtype=torch.float32, device=self.device).reshape(-1, 1)


        # return scaled_actions, raw_action


    def generate_sample(self, batch_size):
        """
        Generates a batch sample from memory for training.

        Returns:
            Tuple: A tuple containing:
                - state_batch (Tensor): The batch of current states.
                - action_batch (Tensor): The batch of actions taken.
                - reward_batch (Tensor): The batch of rewards received.
                - next_state_batch (Tensor): The batch of next states received.
                - done_batch (Tensor): The batch of dones received.
        """
        # Ensure there are enough samples
        if len(self.memory) < batch_size:
            return None

        # Sample a batch from the replay buffer
        batch = self.memory.sample()
        # เมื่อ memory.sample() คืนค่าเป็น tuple: (state_batch, action_batch, reward_batch, next_state_batch, done_batch)
        state_batch, action_batch, reward_batch, next_state_batch, done_batch = batch
        return state_batch, action_batch, reward_batch, next_state_batch, done_batch


    def calculate_loss(self, states, actions, rewards, next_states, dones):
        """
        Computes the loss for policy optimization.

        Args:
            - states (Tensor): The batch of current states.
            - actions (Tensor): The batch of actions taken.
            - rewards (Tensor): The batch of rewards received.
            - next_states (Tensor): The batch of next states received.
            - dones (Tensor): The batch of dones received.

        Returns:
            Tensor: Computed critic & actor loss.
        """
        
        # --- Update Critic ---
        # Compute target actions using target actor network
        with torch.no_grad():
            target_actions = self.actor_target(next_states)
            # Compute target Q-values from target critic
            target_Q = self.critic_target(next_states, target_actions)
            # Compute y = r + gamma * (1 - done) * target_Q
            y = rewards + self.discount_factor * (1 - dones.float()) * target_Q

        # Current Q estimates from the critic
        current_Q = self.critic(states, actions)
        # Critic loss is MSE between current_Q and y
        critic_loss = mse_loss(current_Q, y)

        # --- Update Actor ---
        # Actor loss: we want maximize Q(s, mu(s)) so we minimize -Q(s,mu(s))
        actor_actions = self.actor(states)
        actor_loss = -self.critic(states, actor_actions).mean()


        return critic_loss, actor_loss

        # # --- Update Critic ---
        # with torch.no_grad():
        #     target_actions = self.actor_target(next_states)
        #     target_Q = self.critic_target(next_states, target_actions)
        #     y = rewards + self.discount_factor * (1 - dones.float()) * target_Q

        # current_Q = self.critic(states, actions)
        # critic_loss = mse_loss(current_Q, y)

        # # --- Update Actor ---
        # actor_actions = self.actor(states)
        # # ใช้ clone() เพื่อตัดการแชร์ memory ก่อนส่งเข้า critic
        # actor_loss = -self.critic(states, actor_actions.clone()).mean()

        # return critic_loss, actor_loss
    

        # with torch.no_grad():
        #     target_actions = self.actor_target(next_states)
        #     target_Q = self.critic_target(next_states, target_actions)
        #     y = rewards + self.discount_factor * (1 - dones.float()) * target_Q

        # current_Q = self.critic(states, actions)
        # critic_loss = mse_loss(current_Q, y)

        # actor_actions = self.actor(states)
        # actor_loss = -self.critic(states, actor_actions).mean()
        
        # return critic_loss, actor_loss


    def update_policy(self):
        """
        Update the policy using the calculated loss.

        Returns:
            float: Loss value after the update.
        """
        # sample = self.generate_sample(self.batch_size)
        # if sample is None:
        #     return None

        # states, actions, rewards, next_states, dones = sample

        # # (Optional) Normalize rewards if needed:
        # rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-7)

        # critic_loss, actor_loss = self.calculate_loss(states, actions, rewards, next_states, dones)

        # # --- Update Critic ---
        # self.critic.zero_grad()
        # torch.autograd.set_detect_anomaly(True)
        # critic_loss.backward()
        # # (Optional) Apply gradient clipping:
        # torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 1.0)
        # self.critic_optimizer.step()

        # # --- Update Actor ---
        # self.actor.zero_grad()
        # torch.autograd.set_detect_anomaly(True)
        # actor_loss.backward()
        # torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 1.0)
        # self.actor_optimizer.step()

        # return critic_loss.item(), actor_loss.item()

        sample = self.generate_sample(self.batch_size)
        if sample is None:
            return None

        states, actions, rewards, next_states, dones = sample

        # Normalize rewards
        rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-7)

        # --- Update Critic ---
        # คำนวณ target Q-values โดยไม่ให้มี gradient (detach graph)
        with torch.no_grad():
            target_actions = self.actor_target(next_states)
            target_Q = self.critic_target(next_states, target_actions)
            y = rewards + self.discount_factor * (1 - dones.float()) * target_Q

        current_Q = self.critic(states, actions)
        critic_loss = mse_loss(current_Q, y)

        self.critic.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 1.0)
        self.critic_optimizer.step()

        # --- Update Actor ---
        # ทำ forward ใหม่เพื่อสร้างกราฟสำหรับ actor loss โดยแยกจากกราฟที่ใช้สำหรับ critic loss
        actor_actions = self.actor(states)
        actor_loss = -self.critic(states, actor_actions).mean()

        self.actor.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 1.0)
        self.actor_optimizer.step()

        return critic_loss.item(), actor_loss.item()
    

    def update_target_networks(self, tau=None):
        """
        Perform soft update of target networks using Polyak averaging.

        Args:
            tau (float, optional): Update rate. Defaults to self.tau.
        """
        if tau is None:
            tau = self.tau

        # Update Actor Target
        for target_param, param in zip(self.actor_target.parameters(), self.actor.parameters()):
            target_param.data.copy_(tau * param.data + (1 - tau) * target_param.data)
        
        # Update Critic Target
        for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
            target_param.data.copy_(tau * param.data + (1 - tau) * target_param.data)


    def learn(self, env, max_steps, num_agents, noise_scale=0.1, noise_decay=0.99):
        """
            Train the agent on a single step.

            Args:
                env: The environment in which the agent interacts.
                max_steps (int): Maximum number of steps per episode.
                num_agents (int): Number of agents in the environment.
                noise_scale (float, optional): Initial exploration noise level. Defaults to 0.1.
                noise_decay (float, optional): Factor by which noise decreases per step. Defaults to 0.99.
        """

        # ===== Initialize trajectory collection variables ===== #
        # Reset environment to get initial state (tensor)
        # Track total episode return (float)
        # Flag to indicate episode termination (boolean)
        # Step counter (int)
        # สำหรับ parallel agents, assume env.reset() คืนค่าเป็น batch (Tensor) ที่มี shape [num_agents, state_dim]

        # state, _ = env.reset()
        # total_return = 0.0
        # done = False
        # step = 0
       
        # while not done and step < max_steps:
        
        #     if num_agents > 1:
        #         # ถ้า state เป็น dict ให้ดึง tensor จาก key 'policy'
        #         if isinstance(state, dict) and 'policy' in state:
        #             agent_states = state['policy']
        #         else:
        #             agent_states = state

        #         # ตรวจสอบขนาด batch ถ้า state มีขนาดน้อยกว่า num_agents ให้ replicate
        #         if agent_states.shape[0] < num_agents:
        #             agent_states = agent_states.repeat(num_agents, 1)

        #         # เลือก action สำหรับทุก agent
        #         scaled_actions, _ = self.select_action(agent_states, noise=noise_scale)
                
        #         # ดำเนิน env.step() โดยคาดหวังว่า scaled_actions เป็น batch ของ actions
        #         next_states, rewards, terminated, truncated, _ = env.step(scaled_actions)
                
        #         # ตรวจสอบ next_states ว่าเป็น dict หรือไม่ ถ้าเป็น dict ให้ใช้ key 'policy'
        #         if isinstance(next_states, dict) and 'policy' in next_states:
        #             agent_next_states = next_states['policy']
        #         else:
        #             agent_next_states = next_states

        #         # หาก next_states ยังไม่เป็น batch เท่ากับ num_agents ก็ replicate เช่นกัน
        #         if agent_next_states.shape[0] < num_agents:
        #             agent_next_states = agent_next_states.repeat(num_agents, 1)
                
        #         # สำหรับ terminated และ truncated (assume เป็น Tensors หรือ lists)
        #         dones = torch.logical_or(terminated, truncated)
                
        #         for i in range(num_agents):
        #             self.memory.add(agent_states[i],
        #                             scaled_actions[i].unsqueeze(0),  # ensure proper shape
        #                             torch.tensor([rewards[i]], dtype=torch.float32, device=self.device),
        #                             agent_next_states[i],
        #                             dones[i].item() if isinstance(dones[i].item(), bool) else bool(dones[i]))
                
        #         avg_reward = np.mean(rewards)
        #         total_return += avg_reward
        #         state = agent_next_states




        #     else:
        #         # === Single Agent Training ===
        #         scaled_action, _ = self.select_action(state, noise=noise_scale)
        #         next_state, reward, terminated, truncated, _ = env.step(scaled_action)
        #         done = terminated or truncated
        #         self.memory.add(state,
        #                         scaled_action,
        #                         torch.tensor([reward], dtype=torch.float32, device=self.device),
        #                         next_state,
        #                         done)
        #         total_return += reward
        #         state = next_state

        #     step += 1
        #     # Decay exploration noise
        #     noise_scale *= noise_decay

        #     # Perform optimization
        #     losses = self.update_policy()
        #     self.update_target_networks()

        #     # In parallel agents mode, we may define done as when all agents are done:
        #     if num_agents > 1 and torch.all(torch.tensor(dones)):
        #         done = True

        # # self.plot_durations(step)
        # return total_return, step, losses

        # Reset environment
        state, _ = env.reset()
        total_return = 0.0
        done = False
        step = 0

        while not done and step < max_steps:
            if num_agents > 1:
                # ถ้า state เป็น dict ให้ดึง tensor จาก key 'policy'
                if isinstance(state, dict) and 'policy' in state:
                    agent_states = state['policy']
                else:
                    agent_states = state

                # ตรวจสอบขนาด batch ถ้า state มีขนาดน้อยกว่า num_agents ให้ replicate
                if agent_states.shape[0] < num_agents:
                    agent_states = agent_states.repeat(num_agents, 1)

                # เลือก action สำหรับทุก agent
                scaled_actions, _ = self.select_action(agent_states, noise=noise_scale)
                # scaled_actions มี shape [num_agents, 1]

                # เรียก env.step() ทีละ agent
                next_states_list = []
                rewards_list = []
                terminated_list = []
                truncated_list = []
                for i in range(num_agents):
                    # ส่ง action สำหรับ agent i ซึ่งมี shape [1,1]
                    ns, r, t, tr, _ = env.step(scaled_actions[i].unsqueeze(0))
                    next_states_list.append(ns)
                    rewards_list.append(r)
                    terminated_list.append(t)
                    truncated_list.append(tr)

                # ตรวจสอบ next_states: สมมุติว่า ns ที่ได้เป็น tensor และมี shape [1, state_dim]
                # ดังนั้น เราสามารถใช้ torch.cat เพื่อรวมเป็น tensor ที่มี shape [num_agents, state_dim]
                if isinstance(next_states_list[0], torch.Tensor):
                    agent_next_states = torch.cat(next_states_list, dim=0)
                else:
                    # กรณี ns เป็น dict ที่มี key 'policy' ให้จัดการแบบเดียวกัน
                    agent_next_states = {'policy': torch.cat([ns['policy'] for ns in next_states_list], dim=0)}

                # สำหรับ done flag สร้าง list โดยรวม terminated และ truncated สำหรับแต่ละ agent
                dones_list = []
                for i in range(num_agents):
                    # แปลงให้เป็น boolean
                    dones_list.append(bool(terminated_list[i]) or bool(truncated_list[i]))

                # Update replay buffer ทีละ agent
                for i in range(num_agents):
                    # agent_states[i] เป็น state ของ agent i (รูปแบบ tensor ขนาด [state_dim])
                    # scaled_actions[i].unsqueeze(0) มี shape [1, 1]
                    # torch.tensor([rewards_list[i]], dtype=torch.float32, device=self.device) เป็น reward
                    # agent_next_states[i] เป็น next state (tensor) ของ agent i
                    self.memory.add(
                        agent_states[i],
                        scaled_actions[i].unsqueeze(0),
                        torch.tensor([rewards_list[i]], dtype=torch.float32, device=self.device),
                        agent_next_states[i] if isinstance(agent_next_states, torch.Tensor) else 
                            { 'policy': agent_next_states['policy'][i] },
                        dones_list[i]
                    )

                # avg_reward = np.mean(rewards_list)
                avg_reward = np.mean([r.item() if torch.is_tensor(r) else r for r in rewards_list])
                total_return += avg_reward

                # อัปเดต state ให้เป็นผลลัพธ์ของ env.step() ของ agent ทั้งหมด
                state = agent_next_states

            else:
                # === Single Agent Training ===
                scaled_action, _ = self.select_action(state, noise=noise_scale)
                next_state, reward, terminated, truncated, _ = env.step(scaled_action)
                done = terminated or truncated
                self.memory.add(
                    state,
                    scaled_action,
                    torch.tensor([reward], dtype=torch.float32, device=self.device),
                    next_state,
                    done
                )
                total_return += reward
                state = next_state

            step += 1
            noise_scale *= noise_decay

            # Perform optimization
            losses = self.update_policy()
            self.update_target_networks()

            # In parallel agents mode, you may define done as when all agents are done:
            if num_agents > 1 and all(dones_list):
                done = True

        return total_return, step, losses


    def save_AC_network(self, path: str, filename: str):
        """
        Save actor & critic networks, their optimizers, and training state to disk.
        """
        os.makedirs(path, exist_ok=True)
        file_path = os.path.join(path, f"{filename}.pt")
        torch.save({
            'actor_state_dict': self.actor.state_dict(),
            'critic_state_dict': self.critic.state_dict(),
            'actor_optimizer_state_dict': self.actor_optimizer.state_dict(),
            'critic_optimizer_state_dict': self.critic_optimizer.state_dict(),
            'epsilon': self.epsilon,
        }, file_path)
        print(f"Saved AC checkpoint to {file_path}")

    def load_AC_network(self, path: str, filename: str):
        """
        Load actor & critic networks, their optimizers, and training state from disk.
        """
        file_path = os.path.join(path, f"{filename}.pt")
        checkpoint = torch.load(file_path, map_location=self.device)

        self.actor.load_state_dict(checkpoint['actor_state_dict'])
        self.critic.load_state_dict(checkpoint['critic_state_dict'])
        self.actor_optimizer.load_state_dict(checkpoint['actor_optimizer_state_dict'])
        self.critic_optimizer.load_state_dict(checkpoint['critic_optimizer_state_dict'])
        self.epsilon = checkpoint.get('epsilon', self.epsilon)

        # sync target networks
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

        print(f"Loaded AC checkpoint from {file_path}")