from __future__ import annotations
import numpy as np
from RL_Algorithm.RL_base_function import BaseAlgorithm

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import namedtuple, deque
import random
import matplotlib
import matplotlib.pyplot as plt
import os

class DQN_network(nn.Module):
    """
    Neural network model for the Deep Q-Network algorithm.
    
    Args:
        n_observations (int): Number of input features.
        hidden_size (int): Number of hidden neurons.
        n_actions (int): Number of possible actions.
        dropout (float): Dropout rate for regularization.
    """

    def __init__(self, n_observations, hidden_size, n_hidden_layer, n_actions, dropout):
        super(DQN_network, self).__init__()
        
        # สร้าง list สำหรับเก็บ layers
        layers = []
        # Layer แรก: Input -> Hidden
        layers.append(nn.Linear(n_observations, hidden_size))
        layers.append(nn.ReLU())
        layers.append(nn.Dropout(dropout))
        
        # ชั้นซ่อนเพิ่มเติม (n_hidden_layer - 1 ชั้น)
        for _ in range(n_hidden_layer - 1):
            layers.append(nn.Linear(hidden_size, hidden_size))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
        
        # Output layer: จาก hidden_size ไปยัง n_actions
        layers.append(nn.Linear(hidden_size, n_actions))
        
        # จัดเก็บ layers โดยใช้ nn.Sequential
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        """
        Forward pass through the network.
        
        Args:
            x (Tensor): Input state tensor.
        
        Returns:
            Tensor: Q-value estimates for each action.
        """
        return self.model(x)

class DQN(BaseAlgorithm):
    def __init__(
            self,
            device = None,
            num_of_action: int = 2,
            action_range: list = [-2.5, 2.5],
            n_observations: int = 4,
            hidden_dim: int = 64,
            n_hidden_layer: int = 1,
            dropout: float = 0.5,
            learning_rate: float = 0.01,
            tau: float = 0.005,
            initial_epsilon: float = 1.0,
            epsilon_decay: float = 1e-3,
            final_epsilon: float = 0.001,
            discount_factor: float = 0.95,
            buffer_size: int = 1000,
            batch_size: int = 1,
    ) -> None:
        """
        Initialize the CartPole Agent.

        Args:
            learning_rate (float): The learning rate for updating Q-values.
            initial_epsilon (float): The initial exploration rate.
            epsilon_decay (float): The rate at which epsilon decays over time.
            final_epsilon (float): The final exploration rate.
            discount_factor (float, optional): The discount factor for future rewards. Defaults to 0.95.
        """     

        # Feel free to add or modify any of the initialized variables above.
        # ========= put your code here ========= #
        self.policy_net = DQN_network(n_observations, hidden_dim, n_hidden_layer, num_of_action, dropout).to(device)
        self.target_net = DQN_network(n_observations, hidden_dim, n_hidden_layer, num_of_action, dropout).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())

        self.device = device
        self.steps_done = 0
        self.num_of_action = num_of_action
        self.tau = tau

        self.optimizer = optim.AdamW(self.policy_net.parameters(), lr=learning_rate, amsgrad=True)

        self.episode_durations = []
        self.buffer_size = buffer_size
        self.batch_size = batch_size

        # Experiment with different values and configurations to see how they affect the training process.
        # Remember to document any changes you make and analyze their impact on the agent's performance.

        pass
        # ====================================== #

        super(DQN, self).__init__(
            num_of_action=num_of_action,
            action_range=action_range,
            learning_rate=learning_rate,
            initial_epsilon=initial_epsilon,
            epsilon_decay=epsilon_decay,
            final_epsilon=final_epsilon,  
            discount_factor=discount_factor,
            buffer_size=buffer_size,
            batch_size=batch_size,
        )

        # set up matplotlib
        self.is_ipython = 'inline' in matplotlib.get_backend()
        if self.is_ipython:
            from IPython import display

        plt.ion()

    def select_action(self, state):
        """
        Select an action based on an epsilon-greedy policy.
        
        Args:
            state (Tensor): The current state of the environment.
        
        Returns:
            Tensor: The selected action.
        """
        if random.random() < self.epsilon:
            # Explore: เลือก action แบบสุ่ม
            action_index = random.randrange(self.num_of_action)
        else:
            # Exploit: ใช้ policy_net คำนวณ Q-values และเลือก action ที่มี Q สูงสุด
            # ตรวจสอบว่า state มาในรูปแบบ dict แล้วมี key 'policy'
            if isinstance(state, dict) and 'policy' in state:
                state_tensor = state['policy']  # Tensor shape [1, 4]
            else:
                # กรณีอื่น ๆ แปลง state ให้เป็น Tensor พร้อมเพิ่ม batch dimension
                state_tensor = torch.tensor(state, dtype=torch.float32)
                if state_tensor.dim() == 1:
                    state_tensor = state_tensor.unsqueeze(0)
            
            # ย้าย state_tensor ไปยัง device ที่ใช้งานอยู่
            state_tensor = state_tensor.to(self.device)
            with torch.no_grad():
                q_values = self.policy_net(state_tensor)
                # เลือก action index ที่มี Q-value สูงสุด (โดย q_values มี shape [1, num_of_action])
                action_index = q_values.argmax(dim=1).item()

        return action_index

    def calculate_loss(self, non_final_mask, non_final_next_states, state_batch, action_batch, reward_batch):
        """
        Computes the loss for policy optimization.

        Args:
            non_final_mask (Tensor): Mask indicating which states are non-final.
            non_final_next_states (Tensor): The next states that are not terminal.
            state_batch (Tensor): Batch of current states.
            action_batch (Tensor): Batch of actions taken.
            reward_batch (Tensor): Batch of received rewards.
        
        Returns:
            Tensor: Computed loss.
        """

        # ปรับขนาด state_batch ให้เหมาะสม (เช่น [batch_size, 4])
        state_batch = state_batch.squeeze(1)
        
        # # ปรับขนาด action_batch ให้เป็น [batch_size, 1] (ถ้ามี dimension เกินมา)
        # action_batch = action_batch.squeeze(1)

        # อย่า squeeze ทิ้งเลย ให้แน่ใจว่ามี dim = 2
        if action_batch.dim() == 1:
            action_batch = action_batch.unsqueeze(1)
        
        # คำนวณ Q-values สำหรับ state_batch โดยใช้ policy network
        q_values = self.policy_net(state_batch)    # Q-values shape: [batch_size, num_of_action]
        state_action_values = q_values.gather(1, action_batch)  # action_batch shape: [batch_size, 1]
        
        # สร้าง next_state_values เป็นศูนย์สำหรับแต่ละตัวอย่างใน batch
        next_state_values = torch.zeros(state_batch.size(0), device=self.device)
        
        with torch.no_grad():
            if non_final_next_states.size(0) > 0:
                non_final_next_states = non_final_next_states.squeeze(1)
                target_q = self.target_net(non_final_next_states)
                max_target_q = target_q.max(1)[0]
                next_state_values[non_final_mask] = max_target_q
        
        # คำนวณค่า target Q-value ตามสมการ Bellman
        expected_state_action_values = reward_batch + (self.discount_factor * next_state_values)
        expected_state_action_values = expected_state_action_values.unsqueeze(1)
        
        loss = F.mse_loss(state_action_values, expected_state_action_values)
        return loss

    def generate_sample(self, batch_size):
        """
        Generates a batch sample from memory for training.

        Returns:
            Tuple: A tuple containing:
                - non_final_mask (Tensor): A boolean mask indicating which states are non-final.
                - non_final_next_states (Tensor): The next states that are not terminal.
                - state_batch (Tensor): The batch of current states.
                - action_batch (Tensor): The batch of actions taken.
                - reward_batch (Tensor): The batch of rewards received.
        """
        # Ensure there are enough samples in memory before proceeding
        # ตรวจสอบให้แน่ใจว่ามี sample ใน memory เพียงพอก่อนดำเนินการ
        if len(self.memory) < batch_size:
            return None

        # ดึงข้อมูลตัวอย่างจาก replay buffer
        state_batch, action_batch, reward_batch, next_state_batch, done_batch = self.memory.sample()

        # สร้าง boolean mask สำหรับระบุ non-final states (done == False)
        non_final_mask = ~done_batch  # เปลี่ยน done_batch ให้เป็น mask ของ non-terminal states

        # คัดเลือกเฉพาะ next states ที่ไม่ใช่ terminal จาก next_state_batch
        non_final_next_states = next_state_batch[non_final_mask]

        return non_final_mask, non_final_next_states, state_batch, action_batch, reward_batch

    def update_policy(self):
        """
        Update the policy using the calculated loss.

        Returns:
            float: Loss value after the update.
        """
        # Generate a sample batch
        sample = self.generate_sample(self.batch_size)
        if sample is None:
            return
        
        non_final_mask, non_final_next_states, state_batch, action_batch, reward_batch = sample
        
        # Compute loss
        loss = self.calculate_loss(non_final_mask, non_final_next_states, state_batch, action_batch, reward_batch)

        # Perform gradient descent step
        self.optimizer.zero_grad()  # เคลียร์ gradient เดิม
        loss.backward()             # คำนวณ gradient ใหม่จาก loss
        self.optimizer.step()       # ปรับปรุงค่าน้ำหนักของ policy network

        return loss.item()

    def update_target_networks(self):
        """
        Soft update of target network weights using Polyak averaging.
        """
        # Retrieve the state dictionaries (weights) of both networks
        policy_state_dict = self.policy_net.state_dict()
        target_state_dict = self.target_net.state_dict()

        # Apply the soft update rule to each parameter in the target network
        # โดยการปรับ target parameter เป็น: 
        # target_param = tau * policy_param + (1 - tau) * target_param
        for key in policy_state_dict:
            target_state_dict[key] = self.tau * policy_state_dict[key] + (1.0 - self.tau) * target_state_dict[key]

        # Load the updated weights into the target network
        self.target_net.load_state_dict(target_state_dict)

    def learn(self, env, max_steps=1000):
        """
        Train the agent on a single step.

        Args:
            env: The environment to train in.
    
        Returns:
            float: Total episode return (cumulative reward).
        """

        # ===== Initialize trajectory collection variables ===== #
        # Reset environment to get initial state (tensor)
        # Track total episode return (float)
        # Flag to indicate episode termination (boolean)
        # Step counter (int)
       
        obs, _ = env.reset()
        cumulative_reward = 0.0
        done = False
        timestep = 0

        step_losses = []

        while not done and timestep < max_steps:
            # Predict action from the policy network
            a_idx = self.select_action(obs)

            # map to continuous action
            a_cont = self.scale_action(a_idx)

            # Execute action in the environment and observe next state and reward
            next_obs, reward, terminated, truncated, _ = env.step(a_cont)
            done = terminated or truncated


            # -------- Store the transition in memory -------- #
            # ตรวจสอบ obs ถ้าเป็น dict และมี key 'policy' ให้ใช้ค่า obs['policy']
            if isinstance(obs, dict) and 'policy' in obs:
                state_tensor = obs['policy']
            elif not torch.is_tensor(obs):
                state_tensor = torch.tensor(obs, dtype=torch.float32, device=self.device)
            else:
                state_tensor = obs

            # สำหรับ next_obs เช่นเดียวกัน
            if isinstance(next_obs, dict) and 'policy' in next_obs:
                next_state_tensor = next_obs['policy']
            elif not torch.is_tensor(next_obs):
                next_state_tensor = torch.tensor(next_obs, dtype=torch.float32, device=self.device)
            else:
                next_state_tensor = next_obs

            # แปลง action และ reward ให้อยู่ในรูปแบบ Tensor
            # action_tensor ควรมี shape [1, 1] หรือ [batch_size, 1] ใน ReplayBuffer
            action_tensor = torch.tensor([a_idx], dtype=torch.int64, device=self.device).unsqueeze(0)
            # reward_tensor = torch.tensor([reward], dtype=torch.float32, device=self.device)
            reward_tensor = torch.tensor(reward, dtype=torch.float32, device=self.device)


            # บันทึก transition ลง memory (โดย Transition เก็บ state, action, next_state, reward, done flag)
            self.memory.add(state_tensor, action_tensor, reward_tensor, next_state_tensor, done)

            # -------- Update state and episode return -------- #
            obs = next_obs

            # ถ้า reward เป็น tensor, แปลงให้เป็น float
            if torch.is_tensor(reward):
                reward = reward.cpu().item()

            cumulative_reward += reward

            # -------- Perform one step of optimization -------- #
            loss = self.update_policy()

            if loss is not None:
                step_losses.append(loss)

            # -------- Soft update of the target network's weights -------- #
            self.update_target_networks()

            timestep += 1
            if done:
                self.plot_durations(timestep)
                break
        
        if len(step_losses) > 0:
            avg_loss = np.mean(step_losses)
        else:
            avg_loss = 0

        return cumulative_reward, self.epsilon, timestep, avg_loss 


    def plot_durations(self, timestep=None, show_result=False):
        if timestep is not None:
            self.episode_durations.append(timestep)

        plt.figure(1)
        durations_t = torch.tensor(self.episode_durations, dtype=torch.float)
        if show_result:
            plt.title('Result')
        else:
            plt.clf()
            plt.title('Training...')
        plt.xlabel('Episode')
        plt.ylabel('Duration')
        plt.plot(durations_t.numpy())
        # Take 100 episode averages and plot them too
        if len(durations_t) >= 100:
            means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
            means = torch.cat((torch.zeros(99), means))
            plt.plot(means.numpy())

        plt.pause(0.001)  # pause a bit so that plots are updated
        if self.is_ipython:
            if not show_result:
                display.display(plt.gcf())
                display.clear_output(wait=True)
            else:
                display.display(plt.gcf())

    def save_DQN_network(self, path: str, filename: str):
        """
        Save the policy and target network weights, optimizer state,
        and relevant training parameters to disk.
        """
        os.makedirs(path, exist_ok=True)
        file_path = os.path.join(path, f"{filename}.pt")
        torch.save({
            'policy_state_dict': self.policy_net.state_dict(),
            'target_state_dict': self.target_net.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'epsilon': self.epsilon,
            'steps_done': self.steps_done,
        }, file_path)
        print(f"Saved DQN checkpoint to {file_path}")

    def load_DQN_network(self, path: str, filename: str):
        """
        Load the policy and target network weights, optimizer state,
        and training parameters from disk.
        """
        file_path = os.path.join(path, f"{filename}.pt")
        checkpoint = torch.load(file_path, map_location=self.device)

        self.policy_net.load_state_dict(checkpoint['policy_state_dict'])
        self.target_net.load_state_dict(checkpoint['target_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        # restore epsilon and steps_done if present
        self.epsilon = checkpoint.get('epsilon', self.epsilon)
        self.steps_done = checkpoint.get('steps_done', self.steps_done)

        print(f"Loaded DQN checkpoint from {file_path}")

        
    # ================================================================================== #