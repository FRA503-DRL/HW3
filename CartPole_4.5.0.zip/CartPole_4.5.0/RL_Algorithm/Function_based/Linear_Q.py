from __future__ import annotations
import numpy as np
from RL_Algorithm.RL_base_function import BaseAlgorithm
import random
import torch

class Linear_QN(BaseAlgorithm):
    def __init__(
            self,
            device,
            num_of_action: int = 2,
            action_range: list = [-2.5, 2.5],
            learning_rate: float = 0.01,
            initial_epsilon: float = 1.0,
            epsilon_decay: float = 1e-3,
            final_epsilon: float = 0.001,
            discount_factor: float = 0.95,
            buffer_size: int = 1000,
            batch_size: int = 1,
    ) -> None:
        """
        Initialize the CartPole Agent.

        Args:
            learning_rate (float): The learning rate for updating Q-values.
            initial_epsilon (float): The initial exploration rate.
            epsilon_decay (float): The rate at which epsilon decays over time.
            final_epsilon (float): The final exploration rate.
            discount_factor (float, optional): The discount factor for future rewards. Defaults to 0.95.
        """        
        # เก็บ device ในตัวแปรสมาชิก
        self.device = device

        super().__init__(
            num_of_action=num_of_action,
            action_range=action_range,
            learning_rate=learning_rate,
            initial_epsilon=initial_epsilon,
            epsilon_decay=epsilon_decay,
            final_epsilon=final_epsilon,
            discount_factor=discount_factor,
            buffer_size=buffer_size,
            batch_size=batch_size,
        )
        
    def update(
        self,
        obs,
        action: int,
        reward: float,
        next_obs,
        terminated: bool
    ):
        """
        Updates the weight vector using the Temporal Difference (TD) error 
        in Q-learning with linear function approximation.
        """
        # extract φ(s) โดยตรวจสอบชนิดของ obs
        if isinstance(obs, dict) and 'policy' in obs:
            # รับค่า tensor แล้วย้ายกลับมา CPU และแปลงเป็น numpy array
            phi = obs['policy'][0].detach().cpu().numpy().ravel()
        else:
            phi = obs.cpu().detach().numpy().ravel()

        # Normalize phi
        phi = phi / (np.linalg.norm(phi) + 1e-8)  # กัน divide-by-zero

        # ตรวจสอบ reward หากเป็น tensor ให้แปลงเป็น float
        if torch.is_tensor(reward):
            reward = reward.cpu().item()

        # current Q(s,a)
        q_sa = self.q(obs, action)

        # compute target
        if terminated:
            target = reward
        else:
            # get Q(s',·) as a vector (เป็น numpy array เพราะฟังก์ชัน q ทำการแปลงแล้ว)
            q_next = self.q(next_obs)
            target = reward + self.discount_factor * np.max(q_next)

        # TD error (ควรเป็น float)
        td_error = target - q_sa

        # Clip TD error ก่อนอัปเดต
        td_error = np.clip(td_error, -1.0, 1.0)

        # gradient step on w[:, action]
        # self.w เป็น numpy array ทั้งหมด ดังนั้นทุกตัวคูณต้องอยู่ในรูปแบบ numpy หรือ float
        self.w[:, action] += self.lr * td_error * phi

        loss_value = td_error ** 2

        return loss_value





    def select_action(self, state):
        """
        Select an action based on an epsilon-greedy policy.
        
        Args:
            state (Tensor): The current state of the environment.
        
        Returns:
            Tensor: The selected action.
        """
        if random.random() < self.epsilon:
            # explore
            action = random.randrange(self.num_of_action)
        else:
            # exploitation pick the action with highest Q-value
            q_values = self.q(state)              
            action = int(np.argmax(q_values))

        return action

    def learn(self, env, max_steps):
        """
        Train the agent on a single step.

        Args:
            env: The environment in which the agent interacts.
            max_steps (int): Maximum number of steps per episode.
        """

        # ===== Initialize trajectory collection variables ===== #
        # Reset environment to get initial state (tensor)
        # Track total episode return (float)
        # Flag to indicate episode termination (boolean)
        # Step counter (int)
        
        # reset environment
        obs, _ = env.reset()
        cumulative_reward = 0.0
        done = False
        step = 0

        step_losses = []

        while not done and step < max_steps:
            # choose discrete action index via ε‑greedy
            a_idx = self.select_action(obs)

            # map to continuous action
            a_cont = self.scale_action(a_idx)

            # step the environment
            next_obs, reward, terminated, truncated, _ = env.step(a_cont)
            done = terminated or truncated

            # ถ้า reward เป็น tensor, แปลงให้เป็น float
            if torch.is_tensor(reward):
                reward = reward.cpu().item()

            # update linear Q‑function
            loss = self.update(obs, a_idx, reward, next_obs, done)
            step_losses.append(loss)

            # advance
            obs = next_obs
            cumulative_reward += reward
            step += 1

        if len(step_losses) > 0:
            avg_loss = np.mean(step_losses)
        else:
            avg_loss = 0

        return cumulative_reward, self.epsilon, step, avg_loss
    