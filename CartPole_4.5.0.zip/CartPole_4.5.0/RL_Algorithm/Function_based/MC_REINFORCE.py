from __future__ import annotations
import numpy as np
# from RL_Algorithm.RL_base_function_approximation import BaseAlgorithm, ControlType
from RL_Algorithm.RL_base_function import BaseAlgorithm


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.distributions as distributions
from collections import namedtuple, deque
import random
import matplotlib
import matplotlib.pyplot as plt
import os

class MC_REINFORCE_network(nn.Module):
    """
    Neural network for the MC_REINFORCE algorithm.
    
    Args:
        n_observations (int): Number of input features.
        hidden_size (int): Number of hidden neurons.
        n_actions (int): Number of possible actions.
        dropout (float): Dropout rate for regularization.
    """

    def __init__(self, n_observations, hidden_size, n_hidden_layer, n_actions, dropout):
        super(MC_REINFORCE_network, self).__init__()
        # สร้าง list สำหรับเก็บ layers
        layers = []
        
        # Layer แรก: Input -> Hidden
        layers.append(nn.Linear(n_observations, hidden_size))
        layers.append(nn.ReLU())
        layers.append(nn.Dropout(dropout))
        
        # ชั้นซ่อนเพิ่มเติม (n_hidden_layer - 1 ชั้น)
        for _ in range(n_hidden_layer - 1):
            layers.append(nn.Linear(hidden_size, hidden_size))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
        
        # Output layer: จาก hidden_size ไปยัง n_actions (เอาท์พุตเป็น logits)
        layers.append(nn.Linear(hidden_size, n_actions))
        
        # จัดเก็บ layers โดยใช้ nn.Sequential
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        """
        Forward pass through the network.
        
        Args:
            x (Tensor): Input tensor.
        
        Returns:
            Tensor: Output tensor representing action probabilities.
        """
        # คำนวณ logits จาก network
        logits = self.model(x)
        # ใช้ softmax เพื่อแปลง logits ให้เป็น probability distribution
        action_probabilities = F.softmax(logits, dim=1)
        return action_probabilities


class MC_REINFORCE(BaseAlgorithm):
    def __init__(
            self,
            device = None,
            num_of_action: int = 2,
            action_range: list = [-2.5, 2.5],
            n_observations: int = 4,
            hidden_dim: int = 64,
            n_hidden_layer: int = 1,
            dropout: float = 0.5,
            learning_rate: float = 0.01,
            discount_factor: float = 0.95,
    ) -> None:
        """
        Initialize the CartPole Agent.

        Args:
            learning_rate (float): The learning rate for updating Q-values.
            initial_epsilon (float): The initial exploration rate.
            epsilon_decay (float): The rate at which epsilon decays over time.
            final_epsilon (float): The final exploration rate.
            discount_factor (float, optional): The discount factor for future rewards. Defaults to 0.95.
        """     

        # Feel free to add or modify any of the initialized variables above.
        # ========= put your code here ========= #
        self.LR = learning_rate

        self.policy_net = MC_REINFORCE_network(n_observations, hidden_dim, n_hidden_layer, num_of_action, dropout).to(device)
        self.optimizer = optim.AdamW(self.policy_net.parameters(), lr=learning_rate)

        self.device = device
        self.steps_done = 0

        self.episode_durations = []

        # Experiment with different values and configurations to see how they affect the training process.
        # Remember to document any changes you make and analyze their impact on the agent's performance.

        pass
        # ====================================== #

        super(MC_REINFORCE, self).__init__(
            num_of_action=num_of_action,
            action_range=action_range,
            learning_rate=learning_rate,
            discount_factor=discount_factor,
        )

        # set up matplotlib
        self.is_ipython = 'inline' in matplotlib.get_backend()
        if self.is_ipython:
            from IPython import display

        plt.ion()
    
    def calculate_stepwise_returns(self, rewards):
        """
        Compute stepwise returns for the trajectory.

        Args:
            rewards (list): List of rewards obtained in the episode.
        
        Returns:
            Tensor: Normalized stepwise returns.
        """
    
    
        returns = []
        R = 0.0
        gamma = self.discount_factor
        for r in reversed(rewards):
            R = r + gamma * R
            returns.insert(0, R)
        # returns = torch.tensor(returns, dtype=torch.float32, device=self.device)
        # eps = 1e-8
        # if returns.std() > eps:
        #     returns = (returns - returns.mean()) / (returns.std() + eps)
        # else:
        #     returns = returns - returns.mean()  # หรือ set returns = 0*returns
        # return returns
    

        returns = torch.tensor(returns, dtype=torch.float32, device=self.device)
        eps     = 1e-8
        mu      = returns.mean()
        sigma   = returns.std()
        if sigma > eps:
            # ทำ normalization ปกติ
            returns = (returns - mu) / (sigma + eps)
        else:
            # กรณี sigma≈0: ข้าม mean‑center หรือใช้ alternative scaling
            # Option 1: แค่ subtract mean (จะได้ non‑zero ถ้ามี variation)
            # returns = returns - mu
            # Option 2: scale ด้วย mean absolute ราคา
            returns = returns / (returns.abs().mean() + eps)
        return returns



    def generate_trajectory(self, env, max_steps=1000):
        """
        Generate a trajectory by interacting with the environment.

        Args:
            env: The environment object.
        
        Returns:
            Tuple: (episode_return, stepwise_returns, log_prob_actions, trajectory)
        """
        # ===== Initialize trajectory collection variables ===== #
        # Reset environment to get initial state (tensor)
        # Store state-action-reward history (list)
        # Store log probabilities of actions (list)
        # Store rewards at each step (list)
        # Track total episode return (float)
        # Flag to indicate episode termination (boolean)
        # Step counter (int)

        obs, _ = env.reset()
        
        # เก็บ trajectory ในรูปแบบ list ของ tuple (obs, action, reward, next_obs, done)
        trajectory = []
        # รายการสำหรับเก็บ log probabilities ของ actions ที่ agent เลือก
        log_prob_actions = []
        # รายการสำหรับเก็บ rewards ที่ได้รับ
        rewards = []
        # ค่า cumulative reward ของ episode นี้
        episode_return = 0.0
        # flag สำหรับตรวจสอบว่า episode สิ้นสุดหรือยัง
        done = False
        # ตัวนับ timestep
        timestep = 0

        # ===== Collect trajectory through agent-environment interaction ===== #
        while not done and timestep < max_steps:

            # แปลง observation ให้เป็น Tensor โดยตรวจสอบว่า obs อยู่ในรูปแบบ dictionary หรือไม่
            if isinstance(obs, dict) and 'policy' in obs:
                # ถ้า obs เป็น dict ให้ดึง Tensor จาก key 'policy'
                state_tensor = obs['policy']  # ควรมี shape [1,4] อยู่แล้ว
            else:
                # หาก obs ไม่ใช่ Tensor หรือไม่อยู่ในรูปแบบ dict ให้แปลงให้ถูกต้อง
                if not torch.is_tensor(obs):
                    state_tensor = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
                else:
                    state_tensor = obs.unsqueeze(0) if obs.dim() == 1 else obs

            # Predict action probabilities จาก policy network
            action_probs = self.policy_net(state_tensor)
            # สร้าง Categorical distribution จาก action probabilities
            m = distributions.Categorical(action_probs)
            # ตัวอย่าง action จาก distribution
            action = m.sample()
            # คำนวณ log probability ของ action ที่ได้
            log_prob = m.log_prob(action)
        
            # map to continuous action
            a_cont = self.scale_action(action)

            # Execute action in the environment and observe next state and reward
            next_obs, reward, terminated, truncated, _ = env.step(a_cont)
            done = terminated or truncated

            # บันทึก transition ลงใน trajectory
            trajectory.append((obs, action, reward, next_obs, done))
            log_prob_actions.append(log_prob)
            rewards.append(reward)
            episode_return += reward

            # อัปเดต obs และ timestep
            obs = next_obs
            timestep += 1

            if done:
                self.plot_durations(timestep)
                break

        # ===== Stack log_prob_actions & compute stepwise returns ===== #
        # แปลง log probabilities เป็น Tensor
        log_prob_actions = torch.stack(log_prob_actions)
        # คำนวณ stepwise returns (normalized) โดยใช้ฟังก์ชัน calculate_stepwise_returns
        stepwise_returns = self.calculate_stepwise_returns(rewards)

        return episode_return, stepwise_returns, log_prob_actions, trajectory, timestep
    
    def calculate_loss(self, stepwise_returns, log_prob_actions):
        """
        Compute the loss for policy optimization.

        Args:
            stepwise_returns (Tensor): Stepwise returns for the trajectory.
            log_prob_actions (Tensor): Log probabilities of actions taken.
        
        Returns:
            Tensor: Computed loss.
        """
        # สมการ Loss = - mean( log_prob(a_t) * G_t ) 
        # ใช้ mean เพื่อให้ scale ค่า loss ให้ไม่ขึ้นกับความยาวของ episode
        loss = - (log_prob_actions * stepwise_returns).mean()
        
        return loss

    def update_policy(self, stepwise_returns, log_prob_actions):
        """
        Update the policy using the calculated loss.

        Args:
            stepwise_returns (Tensor): Stepwise returns.
            log_prob_actions (Tensor): Log probabilities of actions taken.
        
        Returns:
            float: Loss value after the update.
        """
         # ล้างค่า gradient เก่าที่สะสมอยู่ใน optimizer
        self.optimizer.zero_grad()
        
        # คำนวณ loss โดยเรียกใช้ฟังก์ชัน calculate_loss ที่คูณ log_prob_actions กับ stepwise_returns
        loss = self.calculate_loss(stepwise_returns, log_prob_actions)
        
        # ทำการ backpropagation เพื่อคำนวณ gradient ของ loss ต่อ parameters ของ policy_net
        loss.backward()
        
        # ปรับปรุงค่าน้ำหนักของ policy_net โดยใช้ optimizer
        self.optimizer.step()
        
        # คืนค่า loss เป็น scalar เพื่อนำไปประเมินประสิทธิภาพการ update
        return loss.item()
    
    def learn(self, env, max_steps=1000):
        """
        Train the agent on a single episode.

        Args:
            env: The environment to train in.
        
        Returns:
            Tuple: (episode_return, loss, trajectory)
        """
        # ========= put your code here ========= #
        self.policy_net.eval()
        episode_return, stepwise_returns, log_prob_actions, trajectory, timestep = self.generate_trajectory(env, max_steps)
        self.policy_net.train()
        loss = self.update_policy(stepwise_returns, log_prob_actions)
        # return episode_return, loss, trajectory
    
        return episode_return, timestep, loss
        # ====================================== #


    # Consider modifying this function to visualize other aspects of the training process.
    # ================================================================================== #
    def plot_durations(self, timestep=None, show_result=False):
        if timestep is not None:
            self.episode_durations.append(timestep)

        plt.figure(1)
        durations_t = torch.tensor(self.episode_durations, dtype=torch.float)
        if show_result:
            plt.title('Result')
        else:
            plt.clf()
            plt.title('Training...')
        plt.xlabel('Episode')
        plt.ylabel('Duration')
        plt.plot(durations_t.numpy())
        # Take 100 episode averages and plot them too
        if len(durations_t) >= 100:
            means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
            means = torch.cat((torch.zeros(99), means))
            plt.plot(means.numpy())

        plt.pause(0.001)  # pause a bit so that plots are updated
        if self.is_ipython:
            if not show_result:
                display.display(plt.gcf())
                display.clear_output(wait=True)
            else:
                display.display(plt.gcf())

    
    def save_MC_network(self, path: str, filename: str):
        """
        Save the policy network weights and optimizer state to disk.
        """
        os.makedirs(path, exist_ok=True)
        file_path = os.path.join(path, f"{filename}.pt")
        torch.save({
            'policy_state_dict': self.policy_net.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, file_path)
        print(f"Saved MC_REINFORCE checkpoint to {file_path}")

    def load_MC_network(self, path: str, filename: str):
        """
        Load the policy network weights and optimizer state from disk.
        """
        file_path = os.path.join(path, f"{filename}.pt")
        checkpoint = torch.load(file_path, map_location=self.device)

        self.policy_net.load_state_dict(checkpoint['policy_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

        print(f"Loaded MC_REINFORCE checkpoint from {file_path}")

    # ================================================================================== #
