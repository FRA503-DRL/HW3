import pandas as pd
import matplotlib.pyplot as plt
import ast
import numpy as np

# อ่านข้อมูลจากไฟล์ CSV (ปรับชื่อไฟล์ตามที่คุณใช้)
csv_file = 'training_metrics_AC6.csv'
data = pd.read_csv(csv_file)

# ฟังก์ชันสำหรับ parse ค่าจากสตริงที่อยู่ในรูปแบบ "(critic_loss, actor_loss)"
def parse_loss(loss_str):
    # ถ้าเป็นค่าว่างหรือ NaN ให้คืน tuple NaN
    if pd.isna(loss_str) or loss_str.strip() == "":
        return np.nan, np.nan
    try:
        # ใช้ ast.literal_eval เพื่อแปลงสตริงให้เป็น tuple
        loss_tuple = ast.literal_eval(loss_str)
        return loss_tuple
    except Exception as e:
        # กรณีเกิดข้อผิดพลาด ให้คืน NaN ทั้งสองค่า
        return np.nan, np.nan

# สร้างคอลัมน์ใหม่สำหรับ critic loss และ actor loss
losses = data['Average_Loss'].apply(parse_loss)
data['Critic_Loss'] = losses.apply(lambda x: x[0])
data['Actor_Loss']  = losses.apply(lambda x: x[1])

# แสดงข้อมูลใน DataFrame (optional)
print(data.head())

# Plot สี่กราฟในหนึ่ง figure: Cumulative Reward, Steps, Critic Loss, Actor Loss
plt.figure(figsize=(14, 10))

# 1. Cumulative Reward vs Episode
plt.subplot(2, 2, 1)
plt.plot(data['Episode'], data['Cumulative_Reward'], marker='o')
plt.title('Cumulative Reward over Episodes')
plt.xlabel('Episode')
plt.ylabel('Cumulative Reward')

# 2. Steps vs Episode
plt.subplot(2, 2, 2)
plt.plot(data['Episode'], data['Steps'], marker='o', color='green')
plt.title('Steps over Episodes')
plt.xlabel('Episode')
plt.ylabel('Steps')

# 3. Critic Loss vs Episode
plt.subplot(2, 2, 3)
plt.plot(data['Episode'], data['Critic_Loss'], marker='o', color='red')
plt.title('Critic Loss over Episodes')
plt.xlabel('Episode')
plt.ylabel('Critic Loss')

# 4. Actor Loss vs Episode
plt.subplot(2, 2, 4)
plt.plot(data['Episode'], data['Actor_Loss'], marker='o', color='purple')
plt.title('Actor Loss over Episodes')
plt.xlabel('Episode')
plt.ylabel('Actor Loss')

plt.tight_layout()
plt.show()
