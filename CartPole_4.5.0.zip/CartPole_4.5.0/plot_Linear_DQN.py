import pandas as pd
import matplotlib.pyplot as plt

def main():
    # อ่านไฟล์ CSV (ตรวจสอบให้แน่ใจว่า path ถูกต้อง)
    csv_file = "training_metrics_DQN.csv"
    try:
        data = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"ไม่พบไฟล์ {csv_file}")
        return

    # แสดง data เบื้องต้น
    print(data.head())

    # กำหนดขนาด figure และสร้าง subplots 2x2
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    fig.suptitle("Training Metrics Visualization", fontsize=16)

    # Plot 1: Cumulative Reward vs Episode (เส้นบางลงด้วย linewidth=1)
    axes[0, 0].plot(
        data["Episode"], data["Cumulative_Reward"], 
        marker='o', linestyle='-', linewidth=0.5, markersize=4
    )
    axes[0, 0].set_title("Cumulative Reward per Episode")
    axes[0, 0].set_xlabel("Episode")
    axes[0, 0].set_ylabel("Cumulative Reward")
    axes[0, 0].grid(True)

    # Plot 2: Epsilon vs Episode
    axes[0, 1].plot(
        data["Episode"], data["Epsilon"], 
        marker='s', color='orange', linestyle='-', linewidth=0.5, markersize=4
    )
    axes[0, 1].set_title("Epsilon Decay")
    axes[0, 1].set_xlabel("Episode")
    axes[0, 1].set_ylabel("Epsilon")
    axes[0, 1].grid(True)

    # Plot 3: Steps vs Episode
    axes[1, 0].plot(
        data["Episode"], data["Steps"], 
        marker='^', color='green', linestyle='-', linewidth=0.5, markersize=4
    )
    axes[1, 0].set_title("Steps per Episode")
    axes[1, 0].set_xlabel("Episode")
    axes[1, 0].set_ylabel("Steps")
    axes[1, 0].grid(True)

    # Plot 4: Average Loss vs Episode
    axes[1, 1].plot(
        data["Episode"], data["Average_Loss"], 
        marker='d', color='red', linestyle='-', linewidth=0.5, markersize=4
    )
    axes[1, 1].set_title("Average Loss per Episode")
    axes[1, 1].set_xlabel("Episode")
    axes[1, 1].set_ylabel("Average Loss")
    axes[1, 1].grid(True)

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()

if __name__ == "__main__":
    main()


# import pandas as pd
# import matplotlib.pyplot as plt

# def main():
#     # อ่านไฟล์ CSV (ตรวจสอบให้แน่ใจว่า path ถูกต้อง)
#     csv_file = "training_metrics_Linear_Q.csv"
#     try:
#         data = pd.read_csv(csv_file)
#     except FileNotFoundError:
#         print(f"ไม่พบไฟล์ {csv_file}")
#         return

#     # แสดง data เบื้องต้น
#     print(data.head())

#     # กำหนดขนาด figure และสร้าง subplots 2x2
#     fig, axes = plt.subplots(2, 2, figsize=(12, 10))
#     fig.suptitle("Training Metrics Visualization", fontsize=16)

#     # Plot 1: Cumulative Reward vs Episode (เส้นบางลงด้วย linewidth=1)
#     axes[0, 0].plot(
#         data["Episode"], data["Cumulative_Reward"], 
#         linestyle='-', linewidth=1
#     )
#     axes[0, 0].set_title("Cumulative Reward per Episode")
#     axes[0, 0].set_xlabel("Episode")
#     axes[0, 0].set_ylabel("Cumulative Reward")
#     axes[0, 0].grid(True)

#     # Plot 2: Epsilon vs Episode
#     axes[0, 1].plot(
#         data["Episode"], data["Epsilon"], 
#         linestyle='-', linewidth=1
#     )
#     axes[0, 1].set_title("Epsilon Decay")
#     axes[0, 1].set_xlabel("Episode")
#     axes[0, 1].set_ylabel("Epsilon")
#     axes[0, 1].grid(True)

#     # Plot 3: Steps vs Episode
#     axes[1, 0].plot(
#         data["Episode"], data["Steps"], 
#         linestyle='-', linewidth=1
#     )
#     axes[1, 0].set_title("Steps per Episode")
#     axes[1, 0].set_xlabel("Episode")
#     axes[1, 0].set_ylabel("Steps")
#     axes[1, 0].grid(True)

#     # Plot 4: Average Loss vs Episode
#     axes[1, 1].plot(
#         data["Episode"], data["Average_Loss"], 
#         linestyle='-', linewidth=1
#     )
#     axes[1, 1].set_title("Average Loss per Episode")
#     axes[1, 1].set_xlabel("Episode")
#     axes[1, 1].set_ylabel("Average Loss")
#     axes[1, 1].grid(True)

#     plt.tight_layout(rect=[0, 0.03, 1, 0.95])
#     plt.show()

# if __name__ == "__main__":
#     main()
