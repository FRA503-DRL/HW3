import pandas as pd
import matplotlib.pyplot as plt

# อ่านข้อมูลจากไฟล์ CSV
data = pd.read_csv('training_metrics_MC_REINFORCE.csv')

# ตั้งค่า figure ด้วยขนาดที่เหมาะสม
plt.figure(figsize=(12, 10))

# Plot Cumulative Reward vs Episode
plt.subplot(2, 2, 1)
plt.plot(data['Episode'], data['Cumulative_Reward'], marker='o')
plt.title('Cumulative Reward over Episodes')
plt.xlabel('Episode')
plt.ylabel('Cumulative Reward')

# # Plot Epsilon vs Episode
# plt.subplot(2, 2, 2)
# plt.plot(data['Episode'], data['Epsilon'], marker='o', color='orange')
# plt.title('Epsilon over Episodes')
# plt.xlabel('Episode')
# plt.ylabel('Epsilon')

# Plot Steps vs Episode
plt.subplot(2, 2, 3)
plt.plot(data['Episode'], data['Steps'], marker='o', color='green')
plt.title('Steps over Episodes')
plt.xlabel('Episode')
plt.ylabel('Steps')

# Plot Average Loss vs Episode
plt.subplot(2, 2, 4)
plt.plot(data['Episode'], data['Average_Loss'], marker='o', color='red')
plt.title('Average Loss over Episodes')
plt.xlabel('Episode')
plt.ylabel('Average Loss')

plt.tight_layout()
plt.show()
