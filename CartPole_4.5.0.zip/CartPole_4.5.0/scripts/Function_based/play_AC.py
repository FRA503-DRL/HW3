"""Script to train RL agent."""

"""Launch Isaac Sim Simulator first."""

import argparse
import sys
import os
import csv

from isaaclab.app import AppLauncher

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from RL_Algorithm.Function_based.AC import Actor_Critic

from tqdm import tqdm

# add argparse arguments
parser = argparse.ArgumentParser(description="Train an RL agent with RSL-RL.")
parser.add_argument("--video", action="store_true", default=False, help="Record videos during training.")
parser.add_argument("--video_length", type=int, default=200, help="Length of the recorded video (in steps).")
parser.add_argument("--video_interval", type=int, default=2000, help="Interval between video recordings (in steps).")
parser.add_argument("--num_envs", type=int, default=1, help="Number of environments to simulate.")
parser.add_argument("--task", type=str, default=None, help="Name of the task.")
parser.add_argument("--seed", type=int, default=None, help="Seed used for the environment")
parser.add_argument("--max_iterations", type=int, default=None, help="RL Policy training iterations.")


# append AppLauncher cli args
AppLauncher.add_app_launcher_args(parser)
args_cli, hydra_args = parser.parse_known_args()

# always enable cameras to record video
if args_cli.video:
    args_cli.enable_cameras = True

# clear out sys.argv for Hydra
sys.argv = [sys.argv[0]] + hydra_args

# launch omniverse app
app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

"""Rest everything follows."""

import gymnasium as gym
import torch
from datetime import datetime
import random

import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple, deque
from itertools import count
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np


from isaaclab.envs import (
    DirectMARLEnv,
    DirectMARLEnvCfg,
    DirectRLEnvCfg,
    ManagerBasedRLEnvCfg,
    multi_agent_to_single_agent,
)
# from omni.isaac.lab.utils.dict import print_dict
from isaaclab_rl.rsl_rl import RslRlOnPolicyRunnerCfg, RslRlVecEnvWrapper
from isaaclab_tasks.utils.hydra import hydra_task_config

# Import extensions to set up environment tasks
import CartPole.tasks  # noqa: F401

torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True
torch.backends.cudnn.deterministic = False
torch.backends.cudnn.benchmark = False

steps_done = 0

@hydra_task_config(args_cli.task, "sb3_cfg_entry_point")
def main(env_cfg: ManagerBasedRLEnvCfg | DirectRLEnvCfg | DirectMARLEnvCfg, agent_cfg: RslRlOnPolicyRunnerCfg):
    """Train with stable-baselines agent."""
    # randomly sample a seed if seed = -1
    if args_cli.seed == -1:
        args_cli.seed = random.randint(0, 10000)

    # override configurations with non-hydra CLI arguments
    env_cfg.scene.num_envs = args_cli.num_envs if args_cli.num_envs is not None else env_cfg.scene.num_envs

    # set the environment seed
    # note: certain randomizations occur in the environment initialization so we set the seed here
    env_cfg.seed = agent_cfg["seed"]
    env_cfg.sim.device = args_cli.device if args_cli.device is not None else env_cfg.sim.device

    # create isaac environment
    env = gym.make(args_cli.task, cfg=env_cfg, render_mode="rgb_array" if args_cli.video else None)

    # ==================================================================== #
    # ========================= Can be modified ========================== #

    # # hyperparameters
    # num_of_action = 1
    # action_range = [-15, 15]
    # learning_rate = 0.0001
    # hidden_dim = 128
    # dropout = 0.1
    # tau = 0.005
    # n_episodes = 100
    # discount = 0.99
    # buffer_size = 512
    # batch_size = 128

      # hyperparameters
    num_of_action = 1
    action_range = [-15, 15]
    learning_rate = 0.0001
    hidden_dim = 128
    dropout = 0.1
    tau = 0.005
    n_episodes = 100
    discount = 0.99
    buffer_size = 5000
    batch_size = 64

    noise_scale = 0.1

    num_agents = 1

    # set up matplotlib
    is_ipython = 'inline' in matplotlib.get_backend()
    if is_ipython:
        from IPython import display

    plt.ion()

    # if GPU is to be used
    device = torch.device(
        "cuda" if torch.cuda.is_available() else
        "mps" if torch.backends.mps.is_available() else
        "cpu"
    )

    print("device: ", device)

    # กำหนดชื่อไฟล์ CSV สำหรับ log metrics (ปรับ path ตามต้องการ)
    log_filename = "testing_metrics_AC.csv"

    # กำหนด header สำหรับไฟล์ CSV
    csv_header = ["Episode", "Cumulative_Reward", "Steps"]

     # เปิดไฟล์ CSV และเขียน header (ถ้ายังไม่มีไฟล์)
    if not os.path.exists(log_filename):
        with open(log_filename, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(csv_header)

    agent =Actor_Critic(
        device=device,
        num_of_action=num_of_action,
        action_range=action_range,
        n_observations= 4,
        learning_rate=learning_rate,
        hidden_dim=hidden_dim,
        dropout=dropout,
        discount_factor = discount,
        tau = tau,
        buffer_size = buffer_size,
        batch_size = batch_size,
    )

    task_name      = str(args_cli.task).split('-')[0]   # eg. "CartPole"
    Algorithm_name = "AC"
    episode        = 1900

    # ชื่อไฟล์ต้องตรงกับที่ save (ไม่มี .pt ต่อท้าย เพราะ .pt จะมาต่อในฟังก์ชัน)
    filename  = f"{Algorithm_name}_{episode}_{num_of_action}_{action_range[1]}"
    full_path = os.path.join("w", task_name, Algorithm_name)

    agent.load_AC_network(full_path, filename)



    # reset environment
    obs, _ = env.reset()
    timestep = 0
    training_log = []
    # simulate environment
    while simulation_app.is_running():
        # run everything in inference mode
        with torch.inference_mode():
        
            for episode in range(n_episodes):

                # Reset environment
                state, _ = env.reset()
                total_return = 0.0
                done = False
                step = 0

                while not done and step < 1000:
                    if num_agents > 1:
                        # ถ้า state เป็น dict ให้ดึง tensor จาก key 'policy'
                        if isinstance(state, dict) and 'policy' in state:
                            agent_states = state['policy']
                        else:
                            agent_states = state

                        # ตรวจสอบขนาด batch ถ้า state มีขนาดน้อยกว่า num_agents ให้ replicate
                        if agent_states.shape[0] < num_agents:
                            agent_states = agent_states.repeat(num_agents, 1)

                        # เลือก action สำหรับทุก agent
                        scaled_actions, _ = agent.select_action(agent_states)
                        # scaled_actions มี shape [num_agents, 1]

                        # เรียก env.step() ทีละ agent
                        next_states_list = []
                        rewards_list = []
                        terminated_list = []
                        truncated_list = []
                        for i in range(num_agents):
                            # ส่ง action สำหรับ agent i ซึ่งมี shape [1,1]
                            ns, r, t, tr, _ = env.step(scaled_actions[i].unsqueeze(0))
                            next_states_list.append(ns)
                            rewards_list.append(r)
                            terminated_list.append(t)
                            truncated_list.append(tr)

                        # ตรวจสอบ next_states: สมมุติว่า ns ที่ได้เป็น tensor และมี shape [1, state_dim]
                        # ดังนั้น เราสามารถใช้ torch.cat เพื่อรวมเป็น tensor ที่มี shape [num_agents, state_dim]
                        if isinstance(next_states_list[0], torch.Tensor):
                            agent_next_states = torch.cat(next_states_list, dim=0)
                        else:
                            # กรณี ns เป็น dict ที่มี key 'policy' ให้จัดการแบบเดียวกัน
                            agent_next_states = {'policy': torch.cat([ns['policy'] for ns in next_states_list], dim=0)}

                        # สำหรับ done flag สร้าง list โดยรวม terminated และ truncated สำหรับแต่ละ agent
                        dones_list = []
                        for i in range(num_agents):
                            # แปลงให้เป็น boolean
                            dones_list.append(bool(terminated_list[i]) or bool(truncated_list[i]))

                        # avg_reward = np.mean(rewards_list)
                        avg_reward = np.mean([r.item() if torch.is_tensor(r) else r for r in rewards_list])
                        total_return += avg_reward

                        # อัปเดต state ให้เป็นผลลัพธ์ของ env.step() ของ agent ทั้งหมด
                        state = agent_next_states

                    else:
                        # === Single Agent Training ===
                        scaled_action, _ = agent.select_action(state, noise=noise_scale)
                        next_state, reward, terminated, truncated, _ = env.step(scaled_action)
                        done = terminated or truncated

                         # ถ้า reward เป็น tensor, แปลงให้เป็น float
                        if torch.is_tensor(reward):
                            reward = reward.cpu().item()

                    
                        total_return += reward
                        state = next_state

                    step += 1

                    # In parallel agents mode, you may define done as when all agents are done:
                    if num_agents > 1 and all(dones_list):
                        done = True

                
                training_log.append([episode, total_return, step])

                with open(log_filename, mode="a", newline="") as file:
                    writer = csv.writer(file)
                    writer.writerows(training_log)
                training_log = []  # เคลียร์ข้อมูลที่เก็บไว้ชั่วคราว
            
        if args_cli.video:
            timestep += 1
            # Exit the play loop after recording one video
            if timestep == args_cli.video_length:
                break

        break
    # ==================================================================== #

    # close the simulator
    env.close()

if __name__ == "__main__":
    # run the main function
    main()
    # close sim app
    simulation_app.close()