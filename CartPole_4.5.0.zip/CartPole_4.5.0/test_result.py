import pandas as pd
import matplotlib.pyplot as plt

# Dictionary of model names to their CSV file paths
files = {
    "Learning_Q": "/home/drl-68/TIK_BAS/HW3/CartPole_4.5.0/training_metrics_Linear_Q8.csv",
    "DQN": "/home/drl-68/TIK_BAS/HW3/CartPole_4.5.0/testing_metrics_DQN7.csv",
    "MC_REINFORCE": "/home/drl-68/TIK_BAS/HW3/CartPole_4.5.0/testing_metrics_MC_REINFORCE3.csv",
    "AC": "/home/drl-68/TIK_BAS/HW3/CartPole_4.5.0/testing_metrics_AC6.csv",
    # เพิ่ม model และไฟล์ตามต้องการ
}

# 1. อ่าน CSV แต่ละไฟล์
dfs = {name: pd.read_csv(path) for name, path in files.items()}

# 2. คำนวณค่าเฉลี่ยของ Cumulative_Reward และ Steps แต่ละ model
results = []
for name, df in dfs.items():
    if 'Cumulative_Reward' not in df.columns or 'Steps' not in df.columns:
        raise KeyError(f"ไฟล์ของ {name} ไม่มีคอลัมน์ 'Cumulative_Reward' หรือ 'Steps'")
    results.append({
        'model': name,
        'mean_reward': df['Cumulative_Reward'].mean(),
        'mean_steps': df['Steps'].mean()
    })

# 3. แปลงเป็น DataFrame และพิมพ์ค่า mean
res_df = pd.DataFrame(results)
print("Mean values per model:")
print(res_df)

# 4. Plot mean cumulative reward
plt.figure(figsize=(8, 5))
plt.bar(res_df['model'], res_df['mean_reward'])
plt.xlabel('Model')
plt.ylabel('Mean Cumulative Reward')
plt.title('Mean Cumulative Reward by Model')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# 5. Plot mean steps
plt.figure(figsize=(8, 5))
plt.bar(res_df['model'], res_df['mean_steps'])
plt.xlabel('Model')
plt.ylabel('Mean Steps')
plt.title('Mean Steps by Model')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
